﻿#ifndef SEARCH_H
#define SEARCH_H

#include <QWidget>
#include <QMessageBox>
#include <QSqlQuery>
#include <QTcpSocket>
#include <QTimer>
#include <QSqlTableModel>
#include <QTableView>

namespace Ui {
class Search;
}

class Search : public QWidget
{
    Q_OBJECT

public:
    explicit Search(QWidget *parent = nullptr);
    void hide_button();
    ~Search();
    QString tagneed;


private slots:
    void on_ButtonSearch_clicked();

private:
    Ui::Search *ui;
    QSqlTableModel *model;
};

#endif // SEARCH_H
