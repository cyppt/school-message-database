﻿#include "cglobal.h"

QString ip;
qint16 port;
QTcpSocket *tcpSocket = NULL;
MainWindow* mywindow;
