﻿#include "search.h"
#include "ui_search.h"

Search::Search(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);
    setWindowTitle("校园生活信息库 ver 1.0");
    ui->label_id->setText("ID:");
    ui->label_user->setText("用户名：");
    ui->label_profile->setPixmap(QPixmap("//获取头像"));
    connect(ui->pushButton_musername, &QPushButton::released, this, &Search::change);
    connect(ui->pushButton_mpassword, &QPushButton::released, this, &Search::change);
    connect(&ui_change, &widget_change::success, this, &Search::dealchange);
    //hide_button();
    //G_如何获取用户权限？？
    model = new QSqlTableModel(this);
    judge_user();//G_我不知道这个model和函数里的model是不是一个model

    model->setTable("");//指定表

    ui->tableView->setModel(model);

    model->select();
    connect(&ui_upload, &Widget_upload::fanhui, this, &Search::dealupload);

}

Search::~Search()
{
    delete ui;
}

//void Search::hide_button()
//{
//    ui->ButtonAns1->hide();
//    ui->ButtonAns2->hide();
//    ui->ButtonAns3->hide();
//    ui->ButtonAns4->hide();
//    ui->ButtonAns5->hide();
//    ui->ButtonAns6->hide();
//    ui->ButtonAns7->hide();
//    ui->ButtonAns8->hide();
//    ui->ButtonAns9->hide();
//    ui->ButtonAnsA->hide();
//    ui->ButtonAnsB->hide();
//    ui->ButtonLast->hide();
//    ui->ButtonNext->hide();
//}

void Search::judge_user()
{
    int k = 0;
    k = 0;//get用户权限 administrator为0 user为1
    if(k == 1)
    {
        ui->pushButton_administrator->hide();
        ui->widget_administrator->hide();
        ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    }else {
       model->setEditStrategy(QSqlTableModel::OnFieldChange);
    }
}


void Search::on_pushButton_upload_clicked()
{
    ui_upload.show();
}

void Search::on_pushButton_sure_clicked()
{
    model->submitAll();
}

void Search::on_pushButton_delete_clicked()
{
    QItemSelectionModel *sModel = ui->tableView->selectionModel();
    QModelIndexList list = sModel->selectedRows();
    for(int i = 0; i < list.size(); i++)
    {
        model->removeRow(list.at(i).row());
    }
}

void Search::on_Button_search_clicked()
{
    QString str = ui->lineEdit_earch->text();
    QString str1 = QString("name = '%1'").arg(str);
    model->setFilter(str);
    model->select();
}

void Search::dealupload()
{
    ui_upload.close();
}

void Search::dealchange()
{
    ui_change.close();
}

void Search::change()
{
    ui_change.show();
}

void Search::on_pushButton_musername_clicked()
{

}
