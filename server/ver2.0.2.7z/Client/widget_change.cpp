﻿#include "widget_change.h"
#include "ui_widget_change.h"

widget_change::widget_change(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::widget_change)
{
    ui->setupUi(this);
    ui->label_title->setText("欢迎注册校园生活信息库查询系统");
    ui->label_username->setText("用户名：");
    ui->label_password->setText("密码：");
    ui->lineEdit_password->setEchoMode(QLineEdit::Password);
    ui->label_password_sure->setText("确认密码：");
    ui->lineEdit_password_sure->setEchoMode(QLineEdit::Password);

}

widget_change::~widget_change()
{
    delete ui;
}

void widget_change::on_button_concrete_clicked()
{
    QString user;
    QString pwd;
    QString pwd_s;
    user = ui->lineEdit_username->text();
    pwd = ui->lineEdit_password->text();
    pwd_s = ui->lineEdit_password_sure->text();

    if(user == "")
        QMessageBox::warning(this,"","用户名不能为空！");
    else if(pwd == "")
        QMessageBox::warning(this,"","密码不能为空！");
    else if(pwd != pwd_s)
        QMessageBox::warning(this,"","两次输入密码不同！");
    else
    {
        QString i= QString("insert into litterfarm.farmer values ('%1','%2'); ").arg(user).arg(pwd_s);
        QString S = QString("select * from litterfarm.farmer where farm_user='%1' ").arg(user);
        QSqlQuery query;
         if(query.exec(i))
            {

             QMessageBox::information(NULL, "修改成功", "修改成功！！！", QMessageBox::Yes);

             emit success();
             //login->show();
             this->close();
         }
         else if(query.exec(S)&&query.first())
            QMessageBox::warning(NULL,"Error","用户名重复！！！");
         else
            QMessageBox::warning(NULL,"Error","修改失败，请重试！！！");
}
}
