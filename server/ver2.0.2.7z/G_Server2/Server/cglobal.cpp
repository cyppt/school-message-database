﻿#include "cglobal.h"
//QTcpServer *tcpServer;
