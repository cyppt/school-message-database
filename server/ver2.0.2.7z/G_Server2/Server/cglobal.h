﻿#ifndef CGLOBAL_H
#define CGLOBAL_H
#include <QString>
#include <QTcpServer>
#include "mainwindow.h"

//extern QTcpServer *tcpServer;
#endif // CGLOBAL_H
