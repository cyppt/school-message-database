﻿#include "search.h"
#include "ui_search.h"

Search::Search(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Search)
{
    ui->setupUi(this);
    setWindowTitle("校园生活信息库 ver 1.0");
    hide_button();
}

Search::~Search()
{
    delete ui;
}

void Search::hide_button()
{
    ui->ButtonAns1->hide();
    ui->ButtonAns2->hide();
    ui->ButtonAns3->hide();
    ui->ButtonAns4->hide();
    ui->ButtonAns5->hide();
    ui->ButtonAns6->hide();
    ui->ButtonAns7->hide();
    ui->ButtonAns8->hide();
    ui->ButtonAns9->hide();
    ui->ButtonAnsA->hide();
    ui->ButtonAnsB->hide();
    ui->ButtonLast->hide();
    ui->ButtonNext->hide();
}
